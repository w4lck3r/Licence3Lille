Socket - Chat Multi Client--------------------------
Url     : http://codes-sources.commentcamarche.net/source/100609-socket-chat-multi-clientAuteur  : Copier212Date    : 15/11/2014
Licence :
=========

Ce document intitul� � Socket - Chat Multi Client � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

C'est une Application Client Serveur de chat multi client
